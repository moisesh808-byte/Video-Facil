[Setup]
AppId=VideoFacil.Moises.Desktop
AppName=VideoFacil
AppVersion=0.4.1
DefaultDirName={localappdata}\Programs\VideoFacil
DefaultGroupName=VideoFacil
PrivilegesRequired=lowest
OutputDir=salida
OutputBaseFilename=VideoFacil-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\VideoFacil.exe
[Files]
Source: "dist\VideoFacil\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
[Icons]
Name: "{group}\VideoFacil"; Filename: "{app}\VideoFacil.exe"
Name: "{autodesktop}\VideoFacil"; Filename: "{app}\VideoFacil.exe"
[Run]
Filename: "{app}\VideoFacil.exe"; Description: "Abrir VideoFacil"; Flags: nowait postinstall skipifsilent
