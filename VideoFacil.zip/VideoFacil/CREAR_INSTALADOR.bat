@echo off
cd /d "%~dp0"
py -3 --version >nul 2>&1
if errorlevel 1 (
 echo Instala Python 3.12 o superior desde https://www.python.org/downloads/windows/
 pause
 exit /b 1
)
py -3 -m venv .venv
if errorlevel 1 goto fallo
.venv\Scripts\python -m pip install --upgrade pip
if errorlevel 1 goto fallo
.venv\Scripts\python -m pip install -r requirements.txt
if errorlevel 1 goto fallo
.venv\Scripts\python preparar_motor.py
if errorlevel 1 goto fallo
.venv\Scripts\python -m PyInstaller --noconfirm --clean --windowed --onedir --name VideoFacil --icon "VideoFacil.ico" --add-binary "yt-dlp.exe;." --collect-all imageio_ffmpeg app.py
if errorlevel 1 goto fallo
set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" (
 echo El programa esta en dist\VideoFacil\VideoFacil.exe
 echo Para generar el instalador, instala Inno Setup 6 desde https://jrsoftware.org/isdl.php y ejecuta este archivo otra vez.
 pause
 exit /b 1
)
"%ISCC%" instalador.iss
if errorlevel 1 goto fallo
echo Listo: salida\VideoFacil-Setup.exe
pause
exit /b 0
:fallo
echo No se completo la compilacion. Revisa el error que aparece arriba.
pause
exit /b 1
