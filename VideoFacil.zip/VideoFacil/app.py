import json
import os
import queue
import re
import sys
import threading
import webbrowser
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
import tkinter as tk
from tkinter import ttk, filedialog, messagebox


import engine
from mp4 import convert_to_mp4


VERSION = '0.4.1'
GITHUB_REPOSITORY = 'moisesh808-byte/Video-Facil'


def check_app_release():
    request = Request(
        f'https://api.github.com/repos/{GITHUB_REPOSITORY}/releases/latest',
        headers={'User-Agent': f'VideoFacil/{VERSION}', 'Accept': 'application/vnd.github+json'},
    )
    try:
        with urlopen(request, timeout=12) as response:
            release = json.load(response)
    except HTTPError as error:
        if error.code == 404:
            return f'Versión instalada: {VERSION}\n\nGitHub no encontró una versión pública publicada.', ''
        raise

    tag = release.get('tag_name', '') if isinstance(release, dict) else ''
    match = re.fullmatch(r'[vV]?([0-9]+)\.([0-9]+)\.([0-9]+)', tag) if isinstance(tag, str) else None
    if match is None:
        raise ValueError('La publicación debe tener una etiqueta de versión como v0.4.1.')
    latest = tuple(map(int, match.groups()))
    current = tuple(map(int, VERSION.split('.')))
    summary = f'Versión instalada: {VERSION}\nÚltima versión publicada: {tag}'
    if latest <= current:
        return summary + '\n\nYa tenés la versión publicada o una más reciente.', ''
    return summary, f'https://github.com/{GITHUB_REPOSITORY}/releases/tag/{tag}'


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f'VideoFácil v{VERSION}')
        self.geometry('820x640')
        self.minsize(740, 620)
        self.configure(background='#111214')
        self.events = queue.Queue()
        self.busy = False
        self.updating = False
        self.url = tk.StringVar()
        self.folder = tk.StringVar(value=str(Path.home() / 'Downloads' / 'VideoFacil'))
        self.quality = tk.StringVar(value='1080p')
        self.output_format = tk.StringVar(value='MP4 compatible con Premiere')
        self.status = tk.StringVar(value='Pegá un enlace para comenzar.')
        style = ttk.Style(self)
        style.theme_use('clam')
        bg, field, text, muted, blue = '#111214', '#202226', '#f4f5f7', '#a9afb9', '#2785ff'
        style.configure('.', background=bg, foreground=text, font=('Segoe UI', 10))
        style.configure('TFrame', background=bg)
        style.configure('TLabel', background=bg, foreground=text)
        style.configure('Muted.TLabel', foreground=muted)
        style.configure('TButton', background=field, foreground=text, bordercolor='#434851',
                        lightcolor=field, darkcolor=field, padding=(16, 10), focuscolor=blue)
        style.map('TButton', background=[('active', '#303640'), ('disabled', '#1c1e22')],
                  foreground=[('disabled', '#69717e')])
        style.configure('Primary.TButton', background=blue, foreground='white',
                        font=('Segoe UI', 13, 'bold'), bordercolor=blue, padding=(16, 13))
        style.map('Primary.TButton', background=[('disabled', '#244d7c'), ('active', '#4597ff')])
        for widget in ('TEntry', 'TCombobox'):
            style.configure(widget, fieldbackground=field, background=field, foreground=text,
                            insertcolor=text, arrowcolor=text, bordercolor='#434851',
                            lightcolor=field, darkcolor=field, padding=9)
            style.map(widget, fieldbackground=[('readonly', field)], foreground=[('readonly', text)],
                      selectbackground=[('readonly', field)], selectforeground=[('readonly', text)])
        style.configure('Horizontal.TProgressbar', background=blue, troughcolor='#30343d',
                        bordercolor='#30343d', lightcolor=blue, darkcolor=blue, thickness=8)
        self.option_add('*TCombobox*Listbox.background', field)
        self.option_add('*TCombobox*Listbox.foreground', text)
        self.option_add('*TCombobox*Listbox.selectBackground', blue)
        box = ttk.Frame(self, padding=(32, 22))
        box.pack(fill='both', expand=True)
        header = ttk.Frame(box)
        header.pack(fill='x')
        tk.Label(header, text='▶', bg=blue, fg='white', font=('Segoe UI', 22),
                 width=2, padx=5, pady=3).pack(side='left', padx=(0, 14))
        title = ttk.Frame(header)
        title.pack(side='left')
        ttk.Label(title, text='VideoFácil', font=('Segoe UI', 28, 'bold')).pack(anchor='w')
        ttk.Label(title, text='Tus videos, en tu PC.', style='Muted.TLabel').pack(anchor='w')
        ttk.Label(box, text='Enlace del video').pack(anchor='w', pady=(24, 7))
        self.entry = ttk.Entry(box, textvariable=self.url)
        self.entry.pack(fill='x')
        row = ttk.Frame(box)
        row.pack(fill='x', pady=(18, 0))
        row.columnconfigure(0, weight=1)
        row.columnconfigure(1, weight=2)
        ttk.Label(row, text='Calidad').grid(row=0, column=0, sticky='w', pady=(0, 7))
        ttk.Label(row, text='Formato de video').grid(row=0, column=1, sticky='w', padx=(16, 0), pady=(0, 7))
        self.combo = ttk.Combobox(row, textvariable=self.quality, state='readonly',
                                 values=['Mejor disponible', '720p', '1080p', '4K', 'Solo audio (MP3)'], width=21)
        self.combo.grid(row=1, column=0, sticky='ew')
        self.format_combo = ttk.Combobox(row, textvariable=self.output_format, state='readonly',
                                       values=['MP4 compatible con Premiere', 'Formato original / MKV'], width=34)
        self.format_combo.grid(row=1, column=1, sticky='ew', padx=(16, 0))
        ttk.Label(box, text='Carpeta de destino').pack(anchor='w', pady=(18, 7))
        destination = ttk.Frame(box)
        destination.pack(fill='x')
        ttk.Entry(destination, textvariable=self.folder, state='readonly').pack(side='left', fill='x', expand=True)
        self.choose = ttk.Button(destination, text='Elegir carpeta', command=self.choose_folder)
        self.choose.pack(side='right', padx=(12, 0))
        self.button = ttk.Button(box, text='↓  Descargar video', command=self.start, style='Primary.TButton')
        self.button.pack(fill='x', pady=(22, 16))
        ttk.Label(box, textvariable=self.status, wraplength=670).pack(anchor='w')
        self.progress = ttk.Progressbar(box, maximum=100)
        self.progress.pack(fill='x', pady=(9, 16))
        actions = ttk.Frame(box)
        actions.pack()
        ttk.Button(actions, text='Abrir carpeta', command=self.open_folder).pack(side='left')
        self.update_button = ttk.Menubutton(actions, text='Buscar actualizaciones')
        update_menu = tk.Menu(self.update_button, tearoff=False, bg=field, fg=text)
        update_menu.add_command(
            label='Buscar versión de VideoFácil',
            command=lambda: self.start_update('VideoFácil', check_app_release),
        )
        update_menu.add_command(
            label='Actualizar motor de descargas',
            command=lambda: self.start_update('Motor de descargas', lambda: (engine.update(), '')),
        )
        self.update_button.configure(menu=update_menu)
        self.update_button.pack(side='left', padx=(12, 0))
        ttk.Label(box, text='MP4: H.264 + AAC · Listo para editar en Premiere',
                  style='Muted.TLabel').pack(pady=(18, 5))
        ttk.Label(box, text='MP3 ignora el formato de video. La conversión a MP4 puede tardar.',
                  style='Muted.TLabel').pack()
        self.after(0, self.dark_titlebar)
        self.protocol('WM_DELETE_WINDOW', self.close)
        self.after(100, self.poll)

    def dark_titlebar(self):
        if sys.platform == 'win32':
            try:
                import ctypes
                hwnd = ctypes.windll.user32.GetParent(self.winfo_id())
                enabled = ctypes.c_int(1)
                for attribute in (20, 19):
                    if ctypes.windll.dwmapi.DwmSetWindowAttribute(
                            hwnd, attribute, ctypes.byref(enabled), ctypes.sizeof(enabled)) == 0:
                        break
            except (OSError, AttributeError):
                pass

    def choose_folder(self):
        path = filedialog.askdirectory()
        if path:
            self.folder.set(path)

    def open_folder(self):
        path = Path(self.folder.get())
        path.mkdir(parents=True, exist_ok=True)
        os.startfile(path)

    def close(self):
        if self.busy:
            action = 'la búsqueda de actualizaciones' if self.updating else 'la descarga'
            messagebox.showinfo('VideoFácil', f'Esperá a que termine {action}.')
            return
        self.destroy()

    def start(self):
        url, folder, quality = self.url.get().strip(), self.folder.get(), self.quality.get()
        try:
            parsed = urlsplit(url)
            if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.password:
                raise ValueError('Pegá un enlace válido que comience con https://')
            Path(folder).mkdir(parents=True, exist_ok=True)
        except (ValueError, OSError) as exc:
            messagebox.showerror('Revisá los datos', str(exc))
            return
        self.set_busy(True)
        self.progress.configure(value=0)
        self.status.set('Conectando…')
        mp4 = quality != 'Solo audio (MP3)' and self.output_format.get() == 'MP4 compatible con Premiere'
        threading.Thread(target=self.download, args=(url, folder, quality, mp4), daemon=True).start()

    def set_busy(self, busy):
        self.busy = busy
        state = 'disabled' if busy else 'normal'
        for button in (self.button, self.choose, self.update_button):
            button.configure(state=state)

    def download(self, url, folder, quality, mp4):
        try:
            import imageio_ffmpeg
            ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
            source = engine.download(url, folder, quality, ffmpeg, self.events)
            if mp4:
                self.events.put(('status', 'Convirtiendo a MP4 para Premiere…'))
                convert_to_mp4(source, ffmpeg)
            self.events.put(('done', 'Descarga terminada. Abrí la carpeta para ver el archivo.'))
        except Exception as exc:
            self.events.put(('error', str(exc)))

    def start_update(self, title, check):
        if self.busy:
            return
        self.updating = True
        self.set_busy(True)
        self.status.set(f'Buscando actualizaciones · {title}…')
        threading.Thread(target=self.check_update, args=(title, check), daemon=True).start()

    def check_update(self, title, check):
        try:
            message, release_url = check()
        except Exception as exc:
            self.events.put(('update_error', (title, str(exc), '')))
        else:
            self.events.put(('update_done', (title, message, release_url)))

    def poll(self):
        try:
            while True:
                kind, value = self.events.get_nowait()
                if kind == 'progress':
                    self.progress.configure(value=value)
                    self.status.set(f'Descargando… {value:.0f}%')
                elif kind == 'status':
                    self.status.set(value)
                elif kind in ('update_done', 'update_error'):
                    self.updating = False
                    self.set_busy(False)
                    title, message, release_url = value
                    if kind == 'update_error':
                        self.status.set('No se pudo completar la búsqueda de actualizaciones.')
                        messagebox.showerror(title, message)
                        continue
                    self.status.set('Búsqueda de actualizaciones completada.')
                    if release_url:
                        if messagebox.askyesno('Actualización disponible', message + '\n\n¿Abrir la descarga en GitHub?'):
                            webbrowser.open(release_url)
                    else:
                        messagebox.showinfo(title, message)
                else:
                    self.set_busy(False)
                    self.status.set(value if kind == 'done' else 'No se pudo descargar el video.')
                    if kind == 'done':
                        self.progress.configure(value=100)
                    else:
                        messagebox.showerror('Descarga no disponible', value)
        except queue.Empty:
            pass
        self.after(100, self.poll)


if __name__ == '__main__':
    App().mainloop()
