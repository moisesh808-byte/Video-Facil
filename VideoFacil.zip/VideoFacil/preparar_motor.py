"""Descarga el ejecutable oficial para incluirlo en el instalador de Windows."""
import hashlib
import json
import os
from pathlib import Path
from urllib.request import Request, urlopen

RELEASE_API = 'https://api.github.com/repos/yt-dlp/yt-dlp/releases/latest'
DESTINATION = Path(__file__).with_name('yt-dlp.exe')


def fetch(url):
    with urlopen(Request(url, headers={'User-Agent': 'VideoFacil-build'}), timeout=60) as response:
        return response.read()


def main():
    release = json.loads(fetch(RELEASE_API))
    assets = {item['name']: item['browser_download_url'] for item in release['assets']}
    checksums = fetch(assets['SHA2-256SUMS']).decode('ascii')
    expected = next(line.split()[0] for line in checksums.splitlines()
                    if line.split() and line.split()[-1].lstrip('*') == DESTINATION.name)
    executable = fetch(assets[DESTINATION.name])
    if hashlib.sha256(executable).hexdigest() != expected.lower():
        raise RuntimeError('La descarga de yt-dlp no coincide con la suma oficial.')
    temporary = DESTINATION.with_suffix('.tmp')
    temporary.write_bytes(executable)
    os.replace(temporary, DESTINATION)
    print('Motor listo:', release['tag_name'])


if __name__ == '__main__':
    main()
