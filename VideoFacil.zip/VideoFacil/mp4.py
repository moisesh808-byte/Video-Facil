"""Conversión final a MP4 para edición, sin depender de ffprobe."""
import os
import subprocess
import tempfile
from pathlib import Path

def convert_to_mp4(source, ffmpeg):
    target = source.with_suffix('.mp4')
    fd, temporary = tempfile.mkstemp(prefix='videofacil-', suffix='.mp4', dir=source.parent)
    os.close(fd)
    try:
        command = [ffmpeg, '-hide_banner', '-loglevel', 'error', '-nostdin',
                   '-y', '-i', str(source), '-map', '0:v:0', '-map', '0:a:0?',
                   '-c:v', 'libx264', '-preset', 'fast', '-crf', '18',
                   '-vf', 'pad=ceil(iw/2)*2:ceil(ih/2)*2', '-pix_fmt', 'yuv420p',
                   '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', temporary]
        result = subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        if result.returncode:
            detail = result.stderr.decode('utf-8', errors='replace')[-2000:]
            raise RuntimeError('No se pudo convertir a MP4. Se conserva la descarga. ' + detail)
        os.replace(temporary, target)
    finally:
        Path(temporary).unlink(missing_ok=True)
    if source != target:
        source.unlink()
