"""Acceso al motor oficial de descarga y a su actualizador."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

SEED = Path(__file__).resolve().parent / 'yt-dlp.exe'
FLAGS = getattr(subprocess, 'CREATE_NO_WINDOW', 0)


def executable():
    folder = Path(os.environ['LOCALAPPDATA']) / 'VideoFacil' / 'motor'
    folder.mkdir(parents=True, exist_ok=True)
    installed = folder / SEED.name
    if not installed.is_file():
        with tempfile.NamedTemporaryFile(dir=folder, delete=False) as stream:
            pending = Path(stream.name)
        try:
            shutil.copyfile(SEED, pending)
            os.replace(pending, installed)
        finally:
            pending.unlink(missing_ok=True)
    return installed


def update():
    motor = str(executable())
    options = dict(capture_output=True, text=True, encoding='utf-8',
                   errors='replace', creationflags=FLAGS)
    version_command = [motor, '--ignore-config', '--version']
    before = subprocess.run(version_command, check=True, timeout=30, **options).stdout.strip()
    result = subprocess.run(
        [motor, '--ignore-config', '--socket-timeout', '30', '-U'],
        timeout=180, **options,
    )
    details = (result.stdout + '\n' + result.stderr).strip()
    if result.returncode:
        raise RuntimeError(details or 'No se pudo actualizar el motor.')
    after = subprocess.run(version_command, check=True, timeout=30, **options).stdout.strip()
    if before == after:
        if 'ERROR:' in details:
            raise RuntimeError(details)
        return f'El motor está al día ({after}).'
    return f'Motor actualizado de {before} a {after}.'


def download(url, folder, quality, ffmpeg, events):
    command = [
        str(executable()), '--ignore-config', '--no-playlist', '--playlist-end', '1',
        '--windows-filenames', '--socket-timeout', '30', '--retries', '3',
        '--ffmpeg-location', ffmpeg, '--encoding', 'utf-8', '--no-colors',
        '--newline', '--progress', '--no-simulate',
        '--progress-template', 'download:VF_PROGRESS:%(progress._percent_str)s',
        '--print', 'after_move:VF_FILE:%(filepath)j',
        '-P', str(Path(folder).resolve()), '-o', '%(title).160B [%(id)s].%(ext)s',
    ]
    if quality == 'Solo audio (MP3)':
        command += ['-f', 'bestaudio/best', '-x', '--audio-format', 'mp3', '--audio-quality', '192K']
    else:
        cap = {'720p': 720, '1080p': 1080, '4K': 2160}.get(quality)
        filt = f'[height<={cap}]' if cap else ''
        command += ['-f', f'bv*{filt}+ba/b{filt}', '--merge-output-format', 'mkv']
    source = None
    last_error = ''
    with subprocess.Popen(
        [*command, '--', url], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding='utf-8', errors='replace', creationflags=FLAGS,
        stdin=subprocess.DEVNULL,
    ) as process:
        for line in process.stdout:
            if line.startswith('VF_PROGRESS:'):
                value = line.split(':', 1)[1].strip().rstrip('%')
                try:
                    events.put(('progress', float(value)))
                except ValueError:
                    pass
            elif line.startswith('VF_FILE:'):
                source = Path(json.loads(line.split(':', 1)[1]))
            elif line.startswith('ERROR:'):
                last_error = line.strip()
        code = process.wait()
    if code or source is None or not source.is_file():
        raise RuntimeError(last_error or 'La plataforma no permitió completar la descarga.')
    return source
